package com.boat.control

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private lateinit var boatManager: BluetoothBoatManager

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { perms ->
        val allGranted = perms.values.all { it }
        if (allGranted) {
            boatManager.checkPairedDevices()
        } else {
            Toast.makeText(this, "Bluetooth permissions are required to detect earbuds", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        try {
            boatManager = BluetoothBoatManager(applicationContext)
        } catch (e: Exception) {
            Toast.makeText(this, "Error initializing: ${e.message}", Toast.LENGTH_LONG).show()
        }

        setContent {
            val state by boatManager.state.collectAsState()
            BoatControlScreen(
                state = state,
                onModeSelected = { boatManager.setMode(it) },
                onAncLevelSelected = { boatManager.setAncLevel(it) },
                onBeastModeToggled = { boatManager.toggleBeastMode(it) },
                onScanClicked = {
                    requestRequiredPermissions()
                    boatManager.startScan()
                },
                onDeviceSelected = { dev ->
                    boatManager.connectToDevice(dev.device)
                },
                onDisconnect = { boatManager.disconnect() }
            )
        }

        // Request permissions after UI composition
        window.decorView.post {
            requestRequiredPermissions()
        }
    }

    private fun requestRequiredPermissions() {
        val permissions = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            permissions.add(Manifest.permission.BLUETOOTH_SCAN)
            permissions.add(Manifest.permission.BLUETOOTH_CONNECT)
        } else {
            permissions.add(Manifest.permission.ACCESS_FINE_LOCATION)
            permissions.add(Manifest.permission.BLUETOOTH)
            permissions.add(Manifest.permission.BLUETOOTH_ADMIN)
        }

        val needed = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (needed.isNotEmpty()) {
            permissionLauncher.launch(needed.toTypedArray())
        } else {
            boatManager.checkPairedDevices()
        }
    }
}

@Composable
fun BoatControlScreen(
    state: EarbudsState,
    onModeSelected: (AncMode) -> Unit,
    onAncLevelSelected: (AncLevel) -> Unit,
    onBeastModeToggled: (Boolean) -> Unit,
    onScanClicked: () -> Unit,
    onDeviceSelected: (DiscoveredDevice) -> Unit,
    onDisconnect: () -> Unit
) {
    val darkBg = Color(0xFF0F172A)
    val cardBg = Color(0xFF1E293B)
    val accentRed = Color(0xFFE11D48)
    val accentCyan = Color(0xFF06B6D4)
    val accentGreen = Color(0xFF10B981)

    val scrollState = rememberScrollState()

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = darkBg
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "boAt Direct Control",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "Real-time BLE • No Account",
                        fontSize = 12.sp,
                        color = Color.LightGray
                    )
                }

                Button(
                    onClick = onScanClicked,
                    colors = ButtonDefaults.buttonColors(containerColor = accentRed),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(if (state.isScanning) "Scanning..." else "Scan Earbuds", fontSize = 12.sp)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Connected Device Status Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = cardBg),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = state.deviceName,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            if (state.macAddress.isNotEmpty()) {
                                Text(
                                    text = state.macAddress,
                                    fontSize = 11.sp,
                                    color = Color.Gray
                                )
                            }
                        }

                        if (state.isConnected) {
                            TextButton(onClick = onDisconnect) {
                                Text("Disconnect", color = Color(0xFFFF5555), fontSize = 12.sp)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .background(
                                    if (state.isConnected) accentGreen else if (state.isConnecting) Color.Yellow else Color.Gray,
                                    shape = CircleShape
                                )
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = state.statusLog,
                            fontSize = 12.sp,
                            color = Color.LightGray
                        )
                    }
                }
            }

            // Discovered / Paired devices picker (if not connected)
            if (state.discoveredDevices.isNotEmpty() && !state.isConnected) {
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "SELECT YOUR AIRDOPES / BOAT DEVICE",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Gray,
                    modifier = Modifier.align(Alignment.Start)
                )
                Spacer(modifier = Modifier.height(6.dp))

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 140.dp)
                ) {
                    items(state.discoveredDevices) { dev ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clickable { onDeviceSelected(dev) },
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF27354A)),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(dev.name, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                    Text(dev.address, color = Color.Gray, fontSize = 11.sp)
                                }
                                Text("Connect", color = accentCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Real Battery Indicators
            Text(
                text = "LIVE BATTERY STATUS",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Gray,
                modifier = Modifier.align(Alignment.Start)
            )
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                BatteryIndicator(
                    label = "Left Bud",
                    level = state.leftBattery,
                    isCharging = state.isLeftCharging,
                    modifier = Modifier.weight(1f),
                    cardBg = cardBg,
                    accentColor = accentCyan
                )
                BatteryIndicator(
                    label = "Right Bud",
                    level = state.rightBattery,
                    isCharging = state.isRightCharging,
                    modifier = Modifier.weight(1f),
                    cardBg = cardBg,
                    accentColor = accentCyan
                )
                BatteryIndicator(
                    label = "Case",
                    level = state.caseBattery,
                    isCharging = state.isCaseCharging,
                    modifier = Modifier.weight(1f),
                    cardBg = cardBg,
                    accentColor = Color(0xFFF59E0B)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Noise Modes
            Text(
                text = "ACTIVE NOISE MODES",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Gray,
                modifier = Modifier.align(Alignment.Start)
            )
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ModeButton(
                    title = "Normal",
                    isSelected = state.currentMode == AncMode.NORMAL,
                    onClick = { onModeSelected(AncMode.NORMAL) },
                    modifier = Modifier.weight(1f)
                )
                ModeButton(
                    title = "ANC",
                    isSelected = state.currentMode == AncMode.ANC,
                    onClick = { onModeSelected(AncMode.ANC) },
                    modifier = Modifier.weight(1f)
                )
                ModeButton(
                    title = "SpeakThrough",
                    isSelected = state.currentMode == AncMode.SPEAKTHROUGH,
                    onClick = { onModeSelected(AncMode.SPEAKTHROUGH) },
                    modifier = Modifier.weight(1f)
                )
            }

            // Always display the 3 ANC Intensity profiles clearly
            Spacer(modifier = Modifier.height(14.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF162032)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "ANC INTENSITY MODES",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = accentCyan
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        AncLevel.values().forEach { lvl ->
                            val isSelected = (state.currentMode == AncMode.ANC && state.ancLevel == lvl)
                            Button(
                                onClick = { 
                                    onAncLevelSelected(lvl)
                                    onModeSelected(AncMode.ANC)
                                },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isSelected) accentCyan else Color(0xFF24334A)
                                ),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp)
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = lvl.title,
                                        fontSize = 11.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) Color.Black else Color.White
                                    )
                                }
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Active: ${state.ancLevel.title} — ${state.ancLevel.subtitle}",
                        fontSize = 11.sp,
                        color = Color.LightGray
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // BEAST MODE (Low Latency Gaming Mode) Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = if (state.isBeastMode) Color(0xFF2E1018) else cardBg
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "BEAST™ MODE",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (state.isBeastMode) accentRed else Color.White
                            )
                            if (state.isBeastMode) {
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "LOW LATENCY ON",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = accentRed
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Reduces audio latency to ~40-50ms for gaming & video sync",
                            fontSize = 11.sp,
                            color = Color.LightGray
                        )
                    }
                    Switch(
                        checked = state.isBeastMode,
                        onCheckedChange = { onBeastModeToggled(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = accentRed,
                            uncheckedThumbColor = Color.LightGray,
                            uncheckedTrackColor = Color(0xFF334155)
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Firmware status
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = cardBg),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Firmware Info", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Earbud Version: ${state.firmwareVersion}",
                        color = Color.LightGray,
                        fontSize = 12.sp
                    )
                }
            }
        }
    }
}

@Composable
fun BatteryIndicator(
    label: String,
    level: Int,
    isCharging: Boolean,
    modifier: Modifier = Modifier,
    cardBg: Color,
    accentColor: Color
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = cardBg),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier
                .padding(10.dp)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(label, color = Color.Gray, fontSize = 11.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = if (level >= 0) "$level%" else "--",
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            LinearProgressIndicator(
                progress = { if (level >= 0) (level / 100f).coerceIn(0f, 1f) else 0f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(5.dp),
                color = accentColor,
                trackColor = Color(0xFF334155)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = if (isCharging) "⚡ Charging" else if (level >= 0) "In Use" else "Disconnected",
                color = if (isCharging) Color(0xFFF59E0B) else Color.LightGray,
                fontSize = 9.sp
            )
        }
    }
}

@Composable
fun ModeButton(
    title: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val selectedBg = Color(0xFFE11D48)
    val normalBg = Color(0xFF1E293B)

    Button(
        onClick = onClick,
        modifier = modifier.height(48.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (isSelected) selectedBg else normalBg
        ),
        shape = RoundedCornerShape(10.dp)
    ) {
        Text(
            text = title,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            color = Color.White
        )
    }
}
